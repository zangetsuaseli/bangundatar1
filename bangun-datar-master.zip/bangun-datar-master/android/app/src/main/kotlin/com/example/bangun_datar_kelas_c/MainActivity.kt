package com.example.bangun_datar_kelas_c

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
